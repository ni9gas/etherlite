import Link from "next/link"
import {
  Shield,
  Zap,
  ArrowRight,
  Bitcoin,
  EclipseIcon as Ethereum,
  CheckCircle,
  AlertTriangle,
  Lock,
  ExternalLink,
} from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen bg-black text-white">
      <header className="border-b border-yellow-600/20 bg-black">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="bg-yellow-500 rounded-md p-2">
              <Shield className="h-6 w-6 text-black" />
            </div>
            <span className="text-2xl font-bold text-yellow-500">Etherlite</span>
          </Link>
          <nav className="hidden md:flex items-center gap-8">
            <Link href="#product" className="text-gray-300 hover:text-yellow-500 transition">
              Product
            </Link>
            <Link href="#features" className="text-gray-300 hover:text-yellow-500 transition">
              Features
            </Link>
            <Link href="#how-it-works" className="text-gray-300 hover:text-yellow-500 transition">
              How It Works
            </Link>
            <Link href="#pricing" className="text-gray-300 hover:text-yellow-500 transition">
              Pricing
            </Link>
          </nav>
          <Button className="bg-yellow-500 hover:bg-yellow-600 text-black font-medium rounded-md">
            Connect Wallet <Wallet className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden py-20 md:py-32 border-b border-yellow-600/20">
          <div className="absolute inset-0 z-0 opacity-30">
            <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-red-900/20 to-transparent"></div>
            <div className="absolute bottom-0 right-0 w-2/3 h-2/3 bg-gradient-to-tl from-yellow-900/20 to-transparent rounded-full blur-3xl"></div>
          </div>

          <div className="container mx-auto px-4 relative z-10">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-8">
                <div className="inline-flex items-center gap-2 bg-red-900/30 border border-red-500/30 rounded-full px-4 py-1">
                  <Zap className="h-4 w-4 text-yellow-500" />
                  <span className="text-sm font-medium">Secure AML Compliance</span>
                </div>

                <h1 className="text-4xl md:text-6xl font-bold leading-tight">
                  <span className="text-white">Trust, but</span> <span className="text-yellow-500">verify</span>{" "}
                  <Zap className="inline-block h-10 w-10 text-yellow-500" />
                </h1>

                <p className="text-xl text-gray-400">
                  The first preventive AML solution for crypto transactions. Protect your assets and stay compliant with
                  regulatory requirements.
                </p>

                <div className="flex flex-col sm:flex-row gap-4">
                  <Button className="bg-yellow-500 hover:bg-yellow-600 text-black font-medium text-lg px-8 py-6 rounded-md">
                    Connect Wallet <Wallet className="ml-2 h-4 w-4" />
                  </Button>
                </div>

                <div className="flex items-center gap-4 text-sm text-gray-400">
                  <div className="flex -space-x-2">
                    {[1, 2, 3, 4].map((i) => (
                      <div
                        key={i}
                        className="w-8 h-8 rounded-full bg-gradient-to-br from-yellow-500 to-red-500 border-2 border-black"
                      ></div>
                    ))}
                  </div>
                  <p>
                    Trusted by <span className="text-yellow-500 font-medium">42,000+</span> crypto wallet
                  </p>
                </div>
              </div>

              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-tr from-red-500/20 to-yellow-500/20 rounded-3xl blur-xl"></div>
                <div className="relative bg-gradient-to-r from-gray-900 to-black border border-yellow-500/20 rounded-3xl p-6 shadow-2xl">
                  <div className="bg-black rounded-2xl p-4 mb-6">
                    <div className="flex justify-between items-center mb-4">
                      <div>
                        <p className="text-sm text-gray-400">Transaction Risk Score</p>
                        <h3 className="text-2xl font-bold text-white">
                          87<span className="text-red-500">/100</span>
                        </h3>
                      </div>
                      <div className="bg-red-500/20 border border-red-500/30 rounded-full p-2">
                        <AlertTriangle className="h-6 w-6 text-red-500" />
                      </div>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-2.5">
                      <div
                        className="bg-gradient-to-r from-yellow-500 to-red-500 h-2.5 rounded-full"
                        style={{ width: "87%" }}
                      ></div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-gray-900 rounded-xl border border-gray-800">
                      <div className="flex items-center gap-3">
                        <div className="bg-black p-2 rounded-full">
                          <Bitcoin className="h-5 w-5 text-yellow-500" />
                        </div>
                        <div>
                          <p className="font-medium">Bitcoin</p>
                          <p className="text-xs text-gray-400">0x7ef9...a3b2</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-red-500 font-medium">High Risk</span>
                        <div className="w-3 h-3 rounded-full bg-red-500"></div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-gray-900 rounded-xl border border-gray-800">
                      <div className="flex items-center gap-3">
                        <div className="bg-black p-2 rounded-full">
                          <Ethereum className="h-5 w-5 text-yellow-500" />
                        </div>
                        <div>
                          <p className="font-medium">Ethereum</p>
                          <p className="text-xs text-gray-400">0x3af1...c4d9</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-yellow-500 font-medium">Medium Risk</span>
                        <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-gray-900 rounded-xl border border-gray-800">
                      <div className="flex items-center gap-3">
                        <div className="bg-black p-2 rounded-full">
                          <Lock className="h-5 w-5 text-yellow-500" />
                        </div>
                        <div>
                          <p className="font-medium">USDC</p>
                          <p className="text-xs text-gray-400">0x8bc2...f7e5</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-green-500 font-medium">Low Risk</span>
                        <div className="w-3 h-3 rounded-full bg-green-500"></div>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full mt-6 bg-yellow-500 hover:bg-yellow-600 text-black font-medium py-3 rounded-xl">
                    Generate Full Report
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-20 border-b border-yellow-600/20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-bold mb-4">
                Advanced AML <span className="text-yellow-500">Protection</span>
              </h2>
              <p className="text-xl text-gray-400 max-w-3xl mx-auto">
                Our platform provides comprehensive anti-money laundering checks for all your crypto transactions
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: <AlertTriangle className="h-10 w-10 text-yellow-500" />,
                  title: "Phishing Warning",
                  description: "Real-time alerts for suspicious wallet addresses and potential scam attempts",
                },
                {
                  icon: <CheckCircle className="h-10 w-10 text-yellow-500" />,
                  title: "Next-Gen Checks",
                  description: "Advanced algorithms to detect unusual patterns and high-risk transactions",
                },
                {
                  icon: <Shield className="h-10 w-10 text-yellow-500" />,
                  title: "Regulatory Compliance",
                  description: "Stay compliant with global AML regulations and avoid legal complications",
                },
                {
                  icon: <Zap className="h-10 w-10 text-yellow-500" />,
                  title: "Real-time Monitoring",
                  description: "Continuous monitoring of all transactions with instant risk assessment",
                },
                {
                  icon: <Lock className="h-10 w-10 text-yellow-500" />,
                  title: "Secure Verification",
                  description: "Multi-layer verification process to ensure maximum security",
                },
                {
                  icon: <ExternalLink className="h-10 w-10 text-yellow-500" />,
                  title: "Web3 Integration",
                  description: "Seamless integration with all major wallets and blockchain platforms",
                },
              ].map((feature, index) => (
                <div
                  key={index}
                  className="bg-gradient-to-br from-gray-900 to-black p-6 rounded-2xl border border-yellow-500/20 hover:border-yellow-500/50 transition duration-300"
                >
                  <div className="bg-black/50 rounded-xl p-3 inline-block mb-4">{feature.icon}</div>
                  <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                  <p className="text-gray-400">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Supported Blockchains */}
        <section className="py-20 border-b border-yellow-600/20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-bold mb-4">
                Supported <span className="text-yellow-500">Blockchains</span>
              </h2>
              <p className="text-xl text-gray-400 max-w-3xl mx-auto">
                We support all major cryptocurrencies and blockchain networks
              </p>
            </div>

            <div className="flex flex-wrap justify-center gap-8">
              {[
                { name: "Bitcoin", icon: "https://cryptologos.cc/logos/bitcoin-btc-logo.png" <img className="h-8 w-8" /> },
                { name: "EVM Network (Ethereum Virtual Machine)", icon: "https://cryptologos.cc/logos/ethereum-eth-logo.png" <img className="h-8 w-8" /> },
                { name: "Solana", icon: "https://upload.wikimedia.org/wikipedia/en/b/b9/Solana_logo.png" <img className="h-8 w-8" /> },
                { name: "Polygon", icon: "https://upload.wikimedia.org/wikipedia/en/b/b9/Solana_logo.png" <img className="h-8 w-8" /> },
              ].map((chain, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 bg-gray-900 rounded-full px-6 py-3 border border-yellow-500/20"
                >
                  <div className="bg-black p-2 rounded-full">
                    {typeof chain.icon === "string" ? (
                      <span className="text-yellow-500 font-bold">{chain.icon}</span>
                    ) : (
                      chain.icon
                    )}
                  </div>
                  <span className="font-medium">{chain.name}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-red-900/30 to-yellow-900/30 rounded-3xl p-8 md:p-12 relative overflow-hidden">
              <div className="absolute inset-0 opacity-30">
                <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-yellow-500/10 rounded-full blur-3xl"></div>
                <div className="absolute bottom-0 left-0 w-1/2 h-1/2 bg-red-500/10 rounded-full blur-3xl"></div>
              </div>

              <div className="relative z-10 max-w-3xl mx-auto text-center">
                <h2 className="text-3xl md:text-5xl font-bold mb-6">
                  Secure your crypto transactions <span className="text-yellow-500">today</span>
                </h2>
                <p className="text-xl text-gray-300 mb-8">
                  Join thousands of businesses and individuals who trust AMLSafe for their crypto compliance needs
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button className="bg-yellow-500 hover:bg-yellow-600 text-black font-medium text-lg px-8 py-6 rounded-md">
                    Start Free Trial
                  </Button>
                  <Button
                    variant="outline"
                    className="border-yellow-500/50 text-yellow-500 hover:bg-yellow-500/10 font-medium text-lg px-8 py-6 rounded-md"
                  >
                    Contact Sales
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-black border-t border-yellow-600/20 py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <Link href="/" className="flex items-center gap-2 mb-4">
                <div className="bg-yellow-500 rounded-md p-2">
                  <Shield className="h-6 w-6 text-black" />
                </div>
                <span className="text-2xl font-bold text-yellow-500">AMLSafe</span>
              </Link>
              <p className="text-gray-400 mb-4">The leading AML compliance solution for cryptocurrency transactions</p>
              <div className="flex gap-4">
                {["Twitter", "LinkedIn", "GitHub", "Discord"].map((social, index) => (
                  <Link key={index} href="#" className="text-gray-400 hover:text-yellow-500 transition">
                    {social}
                  </Link>
                ))}
              </div>
            </div>

            {[
              {
                title: "Product",
                links: ["Features", "Security", "Pricing", "API"],
              },
              {
                title: "Resources",
                links: ["Documentation", "Blog", "Guides", "Support"],
              },
              {
                title: "Company",
                links: ["About Us", "Careers", "Contact", "Privacy Policy"],
              },
            ].map((column, index) => (
              <div key={index}>
                <h3 className="font-bold text-lg mb-4">{column.title}</h3>
                <ul className="space-y-2">
                  {column.links.map((link, linkIndex) => (
                    <li key={linkIndex}>
                      <Link href="#" className="text-gray-400 hover:text-yellow-500 transition">
                        {link}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="border-t border-yellow-600/20 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">© {new Date().getFullYear()} AMLSafe. All rights reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <Link href="#" className="text-gray-400 hover:text-yellow-500 text-sm transition">
                Terms of Service
              </Link>
              <Link href="#" className="text-gray-400 hover:text-yellow-500 text-sm transition">
                Privacy Policy
              </Link>
              <Link href="#" className="text-gray-400 hover:text-yellow-500 text-sm transition">
                Cookie Policy
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}